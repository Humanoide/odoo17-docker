# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class supermodulo17(models.Model):
#     _name = 'supermodulo17.supermodulo17'
#     _description = 'supermodulo17.supermodulo17'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100

